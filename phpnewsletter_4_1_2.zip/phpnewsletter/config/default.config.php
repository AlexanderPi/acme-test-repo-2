<?php

$PNSL["config"]["db"]["host"] = "localhost"; // host
$PNSL["config"]["db"]["name"] = "phpnewsletter"; // database name
$PNSL["config"]["db"]["user"] = "root"; // login
$PNSL["config"]["db"]["passwd"] = ""; // password
$PNSL["config"]["db"]["prefix"] = "pnl_"; // prefix
$PNSL["config"]["db"]["charset"] = "utf8"; // database charset

?>