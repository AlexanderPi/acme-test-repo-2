$(function () {
    $(".block").altSlider(
        {
            url: '/try-it/fifth-demo/fifth-demo.json'
        }
    );
});

