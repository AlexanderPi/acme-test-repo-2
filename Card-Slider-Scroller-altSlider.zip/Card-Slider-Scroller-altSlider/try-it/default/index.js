$(function () {
    $(".block").altSlider(
        {
            url: '/try-it/default/test.json'
        }
    );
});

