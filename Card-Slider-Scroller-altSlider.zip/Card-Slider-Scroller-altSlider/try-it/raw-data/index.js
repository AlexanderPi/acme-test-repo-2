$(function () {
    $(".block").altSlider(
        {
            rawData:
                [
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 1",
                        "create_time": "2018-01-01 00:00:01",
                        "img_src": "http://s5.uploads.ru/t/0hYTP.jpg",
                        "src": "https://google.com"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 2",
                        "create_time": "2018-02-02 00:23:01",
                        "img_src": "http://sa.uploads.ru/t/xqseC.jpg",
                        "src": "https://google.com"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "http://s3.uploads.ru/t/ecM5L.jpg",
                        "src": "https://google.com"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://static.boredpanda.com/blog/wp-content/uploads/2015/03/teletubbies-black-and-white-horror-show-fb.jpg",
                        "src": "https://google.com"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://i1.wp.com/digital-photography-school.com/wp-content/uploads/2007/02/black-and-white-tips.jpg?resize=350%2C211&ssl=1",
                        "src": "https://google.com"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://static.boredpanda.com/blog/wp-content/uploads/2014/08/cat-looking-at-you-black-and-white-photography-1.jpg",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://cdn.vox-cdn.com/thumbor/xRXTAJ1O7F9rCGgEsXv3WqJEKEU=/0x0:3078x1731/1600x900/cdn.vox-cdn.com/uploads/chorus_image/image/54529945/logan_hugh_jackman_wolverine_image.0.jpg",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://static1.squarespace.com/static/50631261e4b0e9530e2c53a7/5586057ee4b087a1e08a2a7a/568780ad2399a3a3e5fc9d9c/1473928641952/Candid-Black-and-White-Photography.jpg?format=500w",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_sVjokt8W2ahY1iJFs-8YeRhgFGgMj4sSe1pAo-lISt22Lvwv",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://upload.wikimedia.org/wikipedia/commons/2/28/Sillitoe-black-white.gif",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSD9NYrx7S4aA7uSGdbi7gUbz8d8ArDjpl76JD06FTys7znJLC58w",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://lensdrop.imgix.net/photos/yoqqp/stock-photo-yoqqp.jpeg?mark=%2Fwms.png&markh=16&h=350&s=8fde1c3f64251d72b8866cc11adcc4a9",
                        "src": "https://google.com?vv=5"
                    },
                    {
                        "title": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi at corporis dignissimos error, facilis ipsum iste iusto, labore minima, nihil obcaecati placeat possimus quasi qui rem saepe soluta voluptates.",
                        "body": "Test body 3",
                        "create_time": "2018-03-02 00:23:01",
                        "img_src": "https://s3.favim.com/orig/46/bird-black-and-white-girl-photography-pretty-Favim.com-426415.jpg",
                        "src": "https://google.com?vv=5"
                    }
                ]
        }
    );
});

