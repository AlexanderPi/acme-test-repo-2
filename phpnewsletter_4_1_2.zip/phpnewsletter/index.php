<?php

/********************************************
* PHP Newsletter 4.1.2
* Copyright (c) 2006-2015 Alexander Yanitsky
* Website: http://janicky.com
* E-mail: janickiy@mail.ru
* Skype: janickiy
********************************************/

require_once dirname(__FILE__)."/ini.php";

?>