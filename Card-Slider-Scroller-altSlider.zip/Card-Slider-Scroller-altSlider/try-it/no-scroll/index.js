$(function () {
    $(".block").altSlider(
        {
            url: 'test.json',
            displayScroll: false
        }
    );
});

