$(function () {
    $(".block").altSlider(
        {
            url: 'auto-scroll.json',
            auto_scroll: 1000
        }
    );
});

