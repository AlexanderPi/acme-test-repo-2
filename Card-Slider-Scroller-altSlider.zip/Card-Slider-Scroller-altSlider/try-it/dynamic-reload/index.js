$(function () {
    $(".block").altSlider(
        {
            url: 'test.json',
            dynamicReload: 3000
        }
    );
});

