<?php

/********************************************
* PHP Newsletter 4.1.2
* Copyright (c) 2006-2015 Alexander Yanitsky
* Website: http://janicky.com
* E-mail: janickiy@mail.ru
* Skype: janickiy
********************************************/

?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Error</title>
</head>
<body>
<p><br><br><br>We're sorry, an application error has occurred! The page is temporarily unavailable:(<br><br><br></p>
</body>
</html>
